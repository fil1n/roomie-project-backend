INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (183, NULL, NULL, 'Алматы', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (14, NULL, NULL, 'Нур-Султан', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (173, NULL, NULL, 'Байконур', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (205, NULL, NULL, 'Усть-Каменогорск', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (284, NULL, NULL, 'Караганда', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (361, NULL, NULL, 'Семей', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (536, NULL, NULL, 'Павлодар', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (706, NULL, NULL, 'Уральск', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (730, NULL, NULL, 'Тараз', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (906, NULL, NULL, 'Кокшетау', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (1006, NULL, NULL, 'Актау', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (2131, NULL, NULL, 'Атырау', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (3193, NULL, NULL, 'Шымкент', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (7279, NULL, NULL, 'Петропавловск', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (21657, NULL, NULL, 'Костанай', NULL, 4);
INSERT INTO city(id, latitude, longitude, name, region_id, citys_country_id) VALUES (1517767, NULL, NULL, 'Актобе', NULL, 4);

